﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fouriere.classes
{
    class velo : deux_roues
    {
        private bool panier;

        public velo(bool panier)
        {
            this.panier = panier;
        }
    }
}
