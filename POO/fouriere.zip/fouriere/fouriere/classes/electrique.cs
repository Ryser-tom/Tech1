﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fouriere.classes
{
    class electrique : velo
    {
        private int puissance_KW;

        public electrique(int puissance_KW)
        {
            this.puissance_KW = puissance_KW;
        }
    }
}
