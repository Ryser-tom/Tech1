﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fouriere.classes
{
    class bicyclette : velo
    {
        private bool fixie;

        public bicyclette(bool fixie)
        {
            this.fixie = fixie;
        }
    }
}
