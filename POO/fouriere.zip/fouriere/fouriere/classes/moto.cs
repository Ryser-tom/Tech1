﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fouriere.classes
{
    class moto : deux_roues
    {
        private bool bride;

        public moto(bool bride)
        {
            this.bride = bride;
        }
    }
}
